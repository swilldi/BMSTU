#!/bin/bash
pos=$(find ./func_tests/data/ -regex ".*pos.*in.txt" | sort)
neg=$(find ./func_tests/data/ -regex ".*neg.*in.txt" | sort)

echo --- POS_TESTS ---
for test in $pos; do
    n_test=$(echo "$test" | grep -Eo "[0-9]{1,2}" )
    valgrind --leak-check=full --log-file=res.txt -- ./app.exe < "$test" > /dev/null
    if grep -q "All heap blocks were freed -- no leaks are possible" res.txt; then
        echo pos_"$n_test": OK
    else
        echo pos_"$n_test": FAIL
    fi
done

echo --- NEG_TESTS ---
for test in $neg; do
    n_test=$(echo "$test" | grep -Eo "[0-9]{1,2}" )
    valgrind --leak-check=full --log-file=res.txt -- ./app.exe < "$test" > /dev/null
    if grep -q "All heap blocks were freed -- no leaks are possible" res.txt; then
        echo neg_"$n_test": OK
    else
        echo neg_"$n_test": FAIL
    fi
done
